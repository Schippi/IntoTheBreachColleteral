UiDeco = Class.new()
function UiDeco:new()
end

function UiDeco:draw(screen,widget)
end

function UiDeco:apply(widget)
end

function UiDeco:unapply(widget)
end
